from odoo import models, fields, api, _


class PartsInventory(models.Model):
    _name = 'parts.inventory'
    _description = 'parts.inventory'
