from odoo import models, fields, api, _


class Configuration(models.Model):
    _name = 'configuration.model'
    _description = 'configuration'

    model_name = fields.Char()
    mobile_brand = fields.Char()


class Complaint(models.Model):
    _name = 'configuration.complaint_template'
    _description = 'complaint_templates'

    complaint_type_template = fields.Char()
    complaint_description = fields.Char()


class Complaint_type(models.Model):
    _name = 'configuration.complaint_type'
    _description = 'complaint_type'

    complaint_type = fields.Char()


class Terms_condition(models.Model):
    _name = 'configuration.terms_condition'
    _description = 'terms_condition'

    terms_and_condition = fields.Char()

