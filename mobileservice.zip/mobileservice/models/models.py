from odoo import models, fields, api,_


class ServiceRequest(models.Model):
    _name = 'mobile.request'
    _description = 'mobile request'

    customer_name = fields.Char()
    contact_number = fields.Char()
    email = fields.Char()
    address = fields.Char()
    mobile_brand = fields.Selection([('samsung', 'Samsung')])
    model_name = fields.Selection([('s24 ultra', 'S24 Ultra')])
    requested_date = fields.Date()
    return_date = fields.Date()
    technician_name = fields.Char()
    in_warranty = fields.Boolean(string="in_warranty")
    re_repair = fields.Boolean(string="re_repair")
    status = fields.Selection([('draft', 'Draft'), ('returned', 'Returned'), ('not_solved', 'Not Solved')],
                              default='draft', string="status")
    seq = fields.Char(copy=False, readonly=True, default=lambda self: _('New'))
    IMEI_number = fields.Char()
    internal_notes = fields.Char()
    treeConnect = fields.One2many('service.request', 'qty')
    treeConnect2 = fields.One2many('complaint.request', 'cat')

    @api.model
    def create(self, vals):
        if vals.get('seq', _('New')) == _('New'):
            vals['seq'] = self.env['ir.sequence'].next_by_code('mobile_request')
        return super(ServiceRequest, self).create(vals)


class ServiceRequestProduct(models.Model):
    _name = 'service.request'
    _description = 'mobile request'

    product = fields.Char()
    used_qty = fields.Char()
    unit_of_measure = fields.Char()
    unit_price = fields.Char()
    stock_move = fields.Char()
    invoice_qty = fields.Char()
    price = fields.Integer()
    qty = fields.Many2one('mobile.request', string="")


class ServiceRequestComplaint(models.Model):
    _name = 'complaint.request'
    _description = 'mobile request'

    category = fields.Char()
    description = fields.Char()
    cat = fields.Many2one('mobile.request', string="")
